extends Node3D
# DR BOKHTAR - game scene (Godot 4). Whole world is built in code.

const N := 60.0
const R := 12.0
const M := 600.0
const DX := [1, 0, -1, 0]
const DZ := [0, 1, 0, -1]
const LAT := [[0, 5], [-5, 0], [0, -5], [5, 0]]

class AI:
	var x := 0.0
	var z := 0.0
	var d := 0
	var s := 0.3
	var node: Node3D

var rng := RandomNumberGenerator.new()
var px := 300.0
var pz := 300.0
var pa := 0.0
var pv := 0.0
var ca := 0.0
var score := 0
var car: Node3D
var cam: Camera3D
var lbl: Label
var traffic: Array[AI] = []
var coins: Array[Node3D] = []


func in_block(x: float, z: float) -> bool:
	if x < 0 or z < 0 or x > M or z > M:
		return false
	var a := fposmod(x, N)
	var b := fposmod(z, N)
	return a > R and a < N - R and b > R and b < N - R


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	return m


func _box(size: Vector3, pos: Vector3, c: Color, parent: Node = null) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.material_override = _mat(c)
	mi.position = pos
	if parent == null:
		parent = self
	parent.add_child(mi)
	return mi


func _make_car(c: Color) -> Node3D:
	var g := Node3D.new()
	add_child(g)
	_box(Vector3(4.4, 1.1, 2.2), Vector3(0, 0.95, 0), c, g)
	_box(Vector3(2.3, 0.9, 1.9), Vector3(-0.3, 1.95, 0), Color(0.14, 0.2, 0.26), g)
	for sx in [1.4, -1.4]:
		for sz in [1.05, -1.05]:
			var w := MeshInstance3D.new()
			var cm := CylinderMesh.new()
			cm.top_radius = 0.5
			cm.bottom_radius = 0.5
			cm.height = 0.4
			w.mesh = cm
			w.material_override = _mat(Color(0.07, 0.07, 0.07))
			w.rotation_degrees = Vector3(90, 0, 0)
			w.position = Vector3(sx, 0.5, sz)
			g.add_child(w)
	return g


func _new_coin(n: Node3D) -> void:
	var t := rng.randf() * M
	var k := float(rng.randi() % 11) * N + (rng.randf() - 0.5) * 14.0
	if rng.randf() < 0.5:
		n.position = Vector3(k, 1.8, t)
	else:
		n.position = Vector3(t, 1.8, k)


func _ready() -> void:
	rng.randomize()
	_setup_input()
	_setup_world()
	_setup_ui()


func _setup_input() -> void:
	var map := {"left": KEY_LEFT, "right": KEY_RIGHT, "gas": KEY_UP, "brake": KEY_DOWN}
	for a in map:
		if not InputMap.has_action(a):
			InputMap.add_action(a)
		var e := InputEventKey.new()
		e.physical_keycode = map[a]
		InputMap.action_add_event(a, e)


func _setup_world() -> void:
	var sky := Color(0.93, 0.63, 0.37)
	var we := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(1.0, 0.88, 0.7)
	env.ambient_light_energy = 0.8
	env.fog_enabled = true
	env.fog_light_color = sky
	env.fog_density = 0.0025
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-50, -30, 0)
	sun.light_color = Color(1.0, 0.75, 0.45)
	add_child(sun)

	var ground := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(3000, 3000)
	ground.mesh = pm
	ground.material_override = _mat(Color(0.3, 0.48, 0.29))
	ground.position = Vector3(300, 0, 300)
	add_child(ground)

	for i in range(11):
		_box(Vector3(M + 2 * R, 0.1, 2 * R), Vector3(M / 2, 0.05, i * N), Color(0.23, 0.24, 0.26))
		_box(Vector3(2 * R, 0.1, M + 2 * R), Vector3(i * N, 0.05, M / 2), Color(0.23, 0.24, 0.26))
		_box(Vector3(M + 2 * R, 0.12, 0.4), Vector3(M / 2, 0.1, i * N), Color(0.9, 0.83, 0.42))
		_box(Vector3(0.4, 0.12, M + 2 * R), Vector3(i * N, 0.1, M / 2), Color(0.9, 0.83, 0.42))

	var pal := [Color(0.72, 0.44, 0.31), Color(0.79, 0.65, 0.42), Color(0.62, 0.71, 0.78), Color(0.85, 0.76, 0.65), Color(0.64, 0.64, 0.5), Color(0.79, 0.48, 0.48), Color(0.5, 0.61, 0.56), Color(0.88, 0.72, 0.45)]
	var hs := [10.0, 16.0, 24.0, 32.0]
	for i in range(10):
		for j in range(10):
			var cx := i * N + N / 2
			var cz := j * N + N / 2
			_box(Vector3(N - 2 * R, 0.4, N - 2 * R), Vector3(cx, 0.2, cz), Color(0.6, 0.61, 0.63))
			if i == 5 and j == 5:
				continue
			var h: float = hs[(i * 3 + j * 5) % 4]
			var w := 22.0 + float((i + j) % 3) * 3.0
			_box(Vector3(w, h, w), Vector3(cx, h / 2 + 0.4, cz), pal[(i * 7 + j * 13) % 8])

	# arch at the start plaza
	var ax := 5 * N + N / 2
	var az := 5 * N + N / 2
	var st := Color(0.85, 0.72, 0.48)
	_box(Vector3(5, 22, 7), Vector3(ax - 9, 11, az), st)
	_box(Vector3(5, 22, 7), Vector3(ax + 9, 11, az), st)
	_box(Vector3(23, 6, 7), Vector3(ax, 25, az), st)

	car = _make_car(Color(0.84, 0.16, 0.16))
	var cols := [Color(0.9, 0.9, 0.9), Color(0.16, 0.44, 0.86), Color(0.95, 0.76, 0.19), Color(0.18, 0.62, 0.36), Color(0.55, 0.27, 0.68), Color(0.13, 0.13, 0.13)]
	for n in range(24):
		var c := AI.new()
		c.d = rng.randi() % 4
		c.s = 0.3 + rng.randf() * 0.25
		var k := float(rng.randi() % 11) * N
		var t := rng.randf() * M
		if c.d % 2 == 0:
			c.x = t
			c.z = k + LAT[c.d][1]
		else:
			c.x = k + LAT[c.d][0]
			c.z = t
		if Vector2(c.x - 300.0, c.z - 300.0).length() < 80.0:
			continue
		c.node = _make_car(cols[rng.randi() % 6])
		traffic.append(c)

	for n in range(28):
		var g := Node3D.new()
		var mi := MeshInstance3D.new()
		var cm := CylinderMesh.new()
		cm.top_radius = 1.2
		cm.bottom_radius = 1.2
		cm.height = 0.3
		mi.mesh = cm
		var m := _mat(Color(0.96, 0.77, 0.19))
		m.emission_enabled = true
		m.emission = Color(0.48, 0.35, 0.0)
		mi.material_override = m
		mi.rotation_degrees = Vector3(90, 0, 0)
		g.add_child(mi)
		_new_coin(g)
		add_child(g)
		coins.append(g)

	cam = Camera3D.new()
	cam.fov = 70.0
	cam.far = 1500.0
	add_child(cam)
	cam.current = true


func _circle_tex(sz: int) -> ImageTexture:
	var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
	var c := Vector2(sz / 2.0, sz / 2.0)
	for y in range(sz):
		for x in range(sz):
			var d := Vector2(x, y).distance_to(c)
			if d < sz / 2.0 - 3.0:
				img.set_pixel(x, y, Color(1, 1, 1, 0.28))
			elif d < sz / 2.0:
				img.set_pixel(x, y, Color(1, 1, 1, 0.8))
	return ImageTexture.create_from_image(img)


func _btn(ui: Node, tex: Texture2D, pos: Vector2, act: String, txt: String) -> void:
	var b := TouchScreenButton.new()
	b.texture_normal = tex
	b.position = pos
	b.action = act
	var sh := CircleShape2D.new()
	sh.radius = 60.0
	b.shape = sh
	ui.add_child(b)
	var l := Label.new()
	l.text = txt
	l.position = Vector2(42, 30)
	l.add_theme_font_size_override("font_size", 42)
	b.add_child(l)


func _setup_ui() -> void:
	var ui := CanvasLayer.new()
	add_child(ui)
	lbl = Label.new()
	lbl.position = Vector2(24, 14)
	lbl.add_theme_font_size_override("font_size", 30)
	ui.add_child(lbl)
	var sz := get_viewport().get_visible_rect().size
	var tex := _circle_tex(120)
	_btn(ui, tex, Vector2(40, sz.y - 160), "left", "<")
	_btn(ui, tex, Vector2(180, sz.y - 160), "right", ">")
	_btn(ui, tex, Vector2(sz.x - 320, sz.y - 160), "brake", "v")
	_btn(ui, tex, Vector2(sz.x - 180, sz.y - 160), "gas", "^")


func _step_ai(c: AI, f: float) -> void:
	var ox := c.x
	var oz := c.z
	var h := c.d % 2 == 0
	c.x += DX[c.d] * c.s * f
	c.z += DZ[c.d] * c.s * f
	var k0 := floori((ox if h else oz) / N)
	var k1 := floori((c.x if h else c.z) / N)
	if k0 == k1:
		return
	var cp: float = maxi(k0, k1) * N
	var o: float = roundf((c.z if h else c.x) / N) * N
	var cx: float = cp if h else o
	var cz: float = o if h else cp
	var opts: Array = []
	for d in range(4):
		if d == (c.d + 2) % 4:
			continue
		var tx: float = cx + DX[d] * N
		var tz: float = cz + DZ[d] * N
		if tx >= 0.0 and tx <= M and tz >= 0.0 and tz <= M:
			opts.append(d)
	if opts.is_empty():
		return
	var nd: int = c.d
	if not (opts.has(c.d) and rng.randf() < 0.5):
		nd = opts[rng.randi() % opts.size()]
	c.d = nd
	c.x = cx + LAT[nd][0]
	c.z = cz + LAT[nd][1]


func _physics_process(dt: float) -> void:
	var f := dt * 60.0
	if Input.is_action_pressed("gas"):
		pv += 0.024 * f
	if Input.is_action_pressed("brake"):
		pv -= 0.03 * f
	pv *= pow(0.985, f)
	pv = clampf(pv, -0.5, 1.2)
	var steer := Input.get_action_strength("right") - Input.get_action_strength("left")
	pa += steer * 0.045 * clampf(pv / 0.5, -1.0, 1.0) * f
	var c := cos(pa)
	var s := sin(pa)
	var nx := px + c * pv * f
	var nz := pz + s * pv * f
	if in_block(nx, nz) or in_block(nx + c * 4.0, nz + s * 4.0) or nx < -10.0 or nz < -10.0 or nx > M + 10.0 or nz > M + 10.0:
		pv *= -0.35
	else:
		px = nx
		pz = nz

	for t in traffic:
		_step_ai(t, f)
		t.node.position = Vector3(t.x, 0, t.z)
		t.node.rotation.y = -t.d * PI / 2.0
		var dd := Vector2(t.x - px, t.z - pz).length()
		if dd < 7.0 and dd > 0.01:
			var qx := px + (px - t.x) / dd * (7.0 - dd)
			var qz := pz + (pz - t.z) / dd * (7.0 - dd)
			if not in_block(qx, qz):
				px = qx
				pz = qz
			pv *= 0.7

	for g in coins:
		g.rotation.y += 0.05 * f
		if Vector2(g.position.x - px, g.position.z - pz).length() < 4.5:
			score += 1
			_new_coin(g)

	car.position = Vector3(px, 0, pz)
	car.rotation.y = -pa
	var da := wrapf(pa - ca, -PI, PI)
	ca += da * minf(1.0, 0.08 * f)
	cam.position = Vector3(px - cos(ca) * 13.0, 6.5, pz - sin(ca) * 13.0)
	cam.look_at(Vector3(px + cos(ca) * 6.0, 1.5, pz + sin(ca) * 6.0))
	lbl.text = "Сомонӣ: %d    %d км/соат" % [score, int(absf(pv) * 90.0)]
