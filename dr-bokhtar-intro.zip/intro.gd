extends Control
# DR BOKHTAR - intro: img1 -> img2 (crossfade + slow zoom), then menu.

var stage: Control
var img1: TextureRect
var img2: TextureRect
var menu: Control
var toast: Label
var intro_tw: Tween
var done := false


func _full(c: Control) -> void:
	c.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)


func _make_img(path: String) -> TextureRect:
	var t := TextureRect.new()
	t.texture = load(path)
	_full(t)
	t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
	t.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return t


func _ready() -> void:
	_full(self)
	var black := ColorRect.new()
	black.color = Color.BLACK
	_full(black)
	black.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(black)
	stage = Control.new()
	_full(stage)
	stage.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(stage)
	img1 = _make_img("res://img1.jpg")
	stage.add_child(img1)
	img2 = _make_img("res://img2.jpg")
	img2.modulate.a = 0.0
	stage.add_child(img2)
	_build_menu()
	toast = Label.new()
	toast.add_theme_font_size_override("font_size", 30)
	toast.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	toast.position.y = 40
	toast.modulate.a = 0.0
	add_child(toast)
	stage.modulate.a = 0.0
	await get_tree().process_frame
	stage.pivot_offset = stage.size / 2.0
	_run_intro()


func _run_intro() -> void:
	intro_tw = create_tween()
	intro_tw.tween_property(stage, "modulate:a", 1.0, 1.0)
	intro_tw.tween_interval(2.2)
	intro_tw.tween_property(img2, "modulate:a", 1.0, 1.6)
	intro_tw.tween_interval(0.6)
	intro_tw.tween_callback(_show_menu)
	var zoom := create_tween()
	zoom.tween_property(stage, "scale", Vector2(1.08, 1.08), 8.0).set_trans(Tween.TRANS_SINE)


func _input(event: InputEvent) -> void:
	if done:
		return
	var tap := (event is InputEventScreenTouch and event.pressed) or (event is InputEventMouseButton and event.pressed)
	if tap:
		if intro_tw:
			intro_tw.kill()
		stage.modulate.a = 1.0
		img2.modulate.a = 1.0
		_show_menu()


func _band(c: Control) -> void:
	c.set_anchor_and_offset(SIDE_LEFT, 0.0, 0.0)
	c.set_anchor_and_offset(SIDE_RIGHT, 1.0, 0.0)
	c.set_anchor_and_offset(SIDE_TOP, 0.72, 0.0)
	c.set_anchor_and_offset(SIDE_BOTTOM, 1.0, 0.0)


func _mk_btn(txt: String) -> Button:
	var b := Button.new()
	b.text = txt
	b.custom_minimum_size = Vector2(300, 90)
	b.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	b.add_theme_font_size_override("font_size", 36)
	for col in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		b.add_theme_color_override(col, Color(0.14, 0.07, 0.0))
	for st in ["normal", "hover", "pressed", "focus"]:
		var s := StyleBoxFlat.new()
		s.bg_color = Color(1.0, 0.8, 0.35) if st == "pressed" else Color(0.96, 0.64, 0.12)
		s.border_color = Color.BLACK
		s.set_border_width_all(4)
		s.set_corner_radius_all(8)
		b.add_theme_stylebox_override(st, s)
	return b


func _build_menu() -> void:
	menu = Control.new()
	_full(menu)
	menu.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu.visible = false
	add_child(menu)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.55)
	_band(shade)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu.add_child(shade)
	var box := HBoxContainer.new()
	_band(box)
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 40)
	menu.add_child(box)
	var b1 := _mk_btn("Оғоз")
	b1.pressed.connect(_on_play)
	box.add_child(b1)
	var b2 := _mk_btn("Танзимот")
	b2.pressed.connect(_on_settings)
	box.add_child(b2)
	var b3 := _mk_btn("Баромад")
	b3.pressed.connect(_on_quit)
	box.add_child(b3)


func _show_menu() -> void:
	if done:
		return
	done = true
	menu.modulate.a = 0.0
	menu.visible = true
	create_tween().tween_property(menu, "modulate:a", 1.0, 0.8)


func _on_play() -> void:
	get_tree().change_scene_to_file("res://game.tscn")


func _on_settings() -> void:
	toast.text = "Танзимот: ба зудӣ"
	toast.modulate.a = 1.0
	create_tween().tween_property(toast, "modulate:a", 0.0, 2.0)


func _on_quit() -> void:
	get_tree().quit()
